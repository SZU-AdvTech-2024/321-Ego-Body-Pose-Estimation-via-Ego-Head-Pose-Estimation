from copycat.khrylib.models.mlp import MLP
from copycat.khrylib.models.rnn import RNN
from copycat.khrylib.models.tcn import TemporalConvNet
from copycat.khrylib.models.resnet import ResNet
from copycat.khrylib.models.discriminator import Discriminator
