from copycat.khrylib.rl.agents.agent_pg import AgentPG
from copycat.khrylib.rl.agents.agent_ppo import AgentPPO
from copycat.khrylib.rl.agents.agent_trpo import AgentTRPO

